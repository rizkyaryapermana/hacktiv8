<?php 
    include_once "koneksi.php";

    // ambil nilai id dari url
    $id = $_GET['id'];

    $sql = "DELETE FROM mahasiswa WHERE id = ".$id;
    $query = mysqli_query($koneksi, $sql);

    if($query){
        header('Location: index.php');
    }else{
        die(mysqli_error($koneksi));
    }

?>
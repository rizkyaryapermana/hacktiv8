<?php 
    include_once "koneksi.php";

    // ambil nilai id dari url
    $id = $_GET['id'];

    $sql = "SELECT * FROM mahasiswa WHERE id = ".$id;
    $query = mysqli_query($koneksi, $sql);

    $data = mysqli_fetch_assoc($query);

    // print_r($data); die;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid">
        <h2>Tambah Data Mahasiswa</h2>
        <a class="btn btn-info mt-2 mb-4" href="index.php">Kembali</a>
        <div class="row">

            <div class="col-md-6">
                
                <form action="process_edit.php" method="POST">
                    <div class="form-group">
                        <label for="nama" class="form-label">Nama: </label>
                        <input type="text" name="nama" id="nama" class="form-control" value="<?php echo $data['nama']; ?>" required />
                    </div>
                    
                    <div class="form-group">
                        <label for="tanggal_lahir" class="form-label">Tanggal Lahir: </label>
                        <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control" value="<?php echo $data['tanggal_lahir']; ?>" required />
                    </div>
                    
                    <div class="form-group">
                        <label for="jurusan" class="form-label">Jurusan: </label>
                        <input type="text" name="jurusan" id="jurusan" class="form-control" value="<?php echo $data['jurusan']; ?>" required />
                    </div>

                    <div class="form-group">
                        <label for="alamat" class="form-label">Alamat: </label>
                        <textarea name="alamat" id="alamat" rows="6" class="form-control" value="<?php echo $data['alamat']; ?>" required><?php echo $data['alamat']; ?></textarea>
                    </div>

                    <input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>" />

                    <button class="btn btn-success mt-4" name="btn-simpan">Simpan</button>

                </form>

            </div>
        </div>
    </div>
</body>
</html>
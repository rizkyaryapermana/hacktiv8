<?php 

    $hostname = 'localhost';
    $username = 'root';
    $password = 'r00tp455'; // kosongkan jika tidak ada password
    $database = 'db_kuliah';

    $koneksi = mysqli_connect($hostname, $username, $password, $database);

    if(!$koneksi){
        echo "Koneksi ke database gagal!";
    }else{
        // echo "Koneksi ke database berhasil!";
    }

?>
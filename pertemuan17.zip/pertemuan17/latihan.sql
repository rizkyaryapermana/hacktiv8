/*
    SQL: 
    1. DDL (Data Definition Language)   --> CREATE, DROP, ALTER
    2. DML (Data Manipulation Language) --> SELECT, INSERT, UPDATE, DELETE
*/

-- membuat database
-- syntax: CREATE DATABASE nama_database;
CREATE DATABASE db_kuliah;

-- menggunakan database
-- syntax: USE nama_database;
USE db_kuliah;

-- membuat tabel
-- syntax: CREATE TABLE nama_tabel;
CREATE TABLE mahasiswa(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jurusan VARCHAR(100) NOT NULL,
    tanggal_lahir DATE NOT NULL,
    alamat TEXT
);

-- menambahkan kolom ke tabel
-- syntax: ALTER TABLE nama_tabel ADD nama_kolom tipe_data(lebar_data)
ALTER TABLE mahasiswa ADD status VARCHAR(15);

-- menghapus kolom dari tabel
-- syntax: ALTER TABLE nama_tabel DROP nama_kolom
ALTER TABLE mahasiswa DROP status;

-- menambahkan data ke tabel
-- syntax: INSERT INTO nama_tabel VALUES();
INSERT INTO mahasiswa VALUES
(NULL, 'Egy Maulana Vikri', 'Teknik Sipil', '1998-10-23', 'Jalan Rengasdengklok No. 1'),
(NULL, 'Witan Sulaiman', 'Manajemen Bisnis', '1999-08-14', 'Jalan Cempaka Putih No. 5');

-- menampilkan data dari tabel
-- menampilkan semua kolom
-- syntax: SELECT * FROM nama_tabel;
SELECT * FROM mahasiswa;

-- menampilkan kolom tertentu dari tabel
-- syntax: SELECT nama_kolom1, ..., nama_kolomx FROM nama_tabel;
-- misal, hanya ingin menampilkan kolom nama dan jurusan
SELECT nama, jurusan FROM mahasiswa;

-- memperbarui data di tabel
-- syntax: UPDATE nama_tabel SET nama_kolom1 = 'nilai_baru', ..., nama_kolomx = 'nilai_baru' WHERE nama_kolom = 'nilai' 
-- misal, ganti jurusan menjadi Teknik Informatika untuk mahasiswa bernama Witan Sulaiman

UPDATE mahasiswa SET jurusan = 'Teknik Informatika' WHERE id = 2;
SELECT * FROM mahasiswa;

-- menghapus data dari tabel
-- syntax: DELETE FROM nama_tabel WHERE nama_kolom = 'nilai'
-- misal, hapus data mahasiswa bernama Egy Maulana Vikri
DELETE FROM mahasiswa WHERE id = 1;
SELECT * FROM mahasiswa;


<?php 

    include_once "koneksi.php";

    if(isset($_POST['btn-simpan'])){
        $nama = $_POST['nama'];
        $tanggal_lahir = $_POST['tanggal_lahir'];
        $jurusan = $_POST['jurusan'];
        $alamat = $_POST['alamat'];

        // print_r($_POST); die;
        $sql = "INSERT INTO mahasiswa VALUES(NULL, '$nama', '$jurusan', '$tanggal_lahir', '$alamat')";
        // echo $sql; die;
        $query = mysqli_query($koneksi, $sql);

        if($query){
            // redirect ke halaman index.php ketika insert berhasil
            header('Location: index.php');
        }else{
            // tampilkan error ketika gagal
            die(mysqli_error($koneksi));
        }

    }

?>
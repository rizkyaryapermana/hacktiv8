<?php 

    include_once "koneksi.php";

    if(isset($_POST['btn-simpan'])){
        $id = $_POST['id'];
        $nama = $_POST['nama'];
        $tanggal_lahir = $_POST['tanggal_lahir'];
        $jurusan = $_POST['jurusan'];
        $alamat = $_POST['alamat'];

        // print_r($_POST); die;
        $sql = "UPDATE mahasiswa SET nama = '$nama', tanggal_lahir = '$tanggal_lahir', jurusan = '$jurusan', alamat = '$alamat' WHERE id = ".$id;
        // echo $sql; die;
        $query = mysqli_query($koneksi, $sql);

        if($query){
            // redirect ke halaman index.php ketika insert berhasil
            header('Location: index.php');
        }else{
            // tampilkan error ketika gagal
            die(mysqli_error($koneksi));
        }

    }

?>